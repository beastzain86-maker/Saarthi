Saarthi download website (single page)

FILES
- index.html : the complete website (HTML, CSS and JS are inside this one file)

HOW TO GO LIVE
GitHub Pages:
 1. Create a new repository on GitHub (public).
 2. Upload index.html to the repository (Add file > Upload files).
 3. Settings > Pages > Source: "Deploy from a branch", Branch: main, folder: / (root). Save.
 4. After about a minute your site is live at https://YOUR-USERNAME.github.io/REPO-NAME/

Netlify / Cloudflare Pages / Vercel:
 Drag and drop this folder (or the zip) into the dashboard. Done.

Any normal hosting (cPanel etc.):
 Upload index.html into the public_html folder.

CHANGE THE DOWNLOAD LINK
Open index.html in a text editor and search for: 12QGmzff1E7yVk8YbHC2pBYtVOwVxBZ4_
Replace it with your new Google Drive file ID (3 places). The ID is the part between /d/ and /view in your Drive link.

NOTE
Your Google Drive file must be shared as: Anyone with the link (Viewer).
